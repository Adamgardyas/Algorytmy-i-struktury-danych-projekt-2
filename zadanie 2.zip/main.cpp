#include <iostream>
#include <cstdlib>
#include <time.h>
#include <iomanip>
#include <cmath>
#include <fstream>
#include <ctype.h>

using namespace std;

//okreslamy wielkosc naszego zbioru
const int N=100;

//deklarujemy przedzialy
int g[N], h[N];

#include <cstdio>
#include <ctime>

//tworzymy funkcje zliczajaca czas dzialania naszego programu
void czekaj( int ile )
{
    clock_t koniec = clock() + ile * CLOCKS_PER_SEC;

}

double czas( clock_t czas )
{
    return static_cast < double >( czas ) / CLOCKS_PER_SEC;
}


//deklarujemy zmienne gdzie p-indeks pierwszego agrumentu w mlodszym podzbiorze, k-indeks ostatniego agrumentu w starszym podzbiorze
void scalanie(int p, int k)
    {
//deklarujemy potrzebne zmienne gdzie s-indeks pierwszego argumentu w starszym podzbiorze, i1-mlodsza pol�wka zbioru, i2-starsza pol�wka zbioru, i-zbi�r tymaczasowy
    int i, i1, i2, s;
    //podzial zbioru na 2 rowne czesci
        s=(p+k+1)/2;
            if(s-p>0) scalanie(p, s-1);
            if(k-s>0) scalanie(s, k);
        i1=p;
        i2=s;
        //zastosowanie sortowania przez scalanie
            for(i=p; i<=k; i++)
        h[i]=(i1==s) || ((i2<=k) && (g[i1]>g[i2]))?
        g[i2++] : g[i1++];
        //polaczenie posotrowanych ciagow w jeden ciag
            for(i=p; i<=k; i++) g[i]=h[i];
}


int main()
{
    int i, j, k, m, x;

    cout<<"Zbior losowych liczb:"<<endl;
    srand((unsigned)time(NULL));
    //losujemy liczby z przedzialu [0;1000]
        for(i = 0; i < N+1; i++) g[i] = rand() % 1001;
    //wypisujemy wylosowane liczby
            for(i = 0; i < N; i++)cout<<setw(5)<<g[i];
        cout<<endl;

        //sprawdzanie pesymistycznej/optymistycznej wersji
        /*int g[]={20,19,18,17,16,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1};
        int g[]={2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22};
        cout<<"Zbior: "<<endl;
            for (i=1; i<N+1; i++)
                cout << setw(5) << g[i];
            cout<<endl;*/

        scalanie(0,N);

        //wywolujemy napis
    cout<<"Wynik sortowania przez scalanie:"<<endl;
        for( i = 0; i < N+1; i++)
            //wypisujemy posortowany ciag liczb
        cout<<setw(5)<<g[i];
        cout<<endl;

    //budujemy kopiec
    for(i = 2; i <= N; i++)
  {
    j = i; k = j / 2;
    x = g[i];
    while((k > 0) && (g[k] < x))
    {
      g[j] = g[k];
      j = k; k = j / 2;
    }
    g[j] = x;
  }
    //rozbieramy kopiec
    for(i = N; i > 1; i--)
  {
    swap(g[1], g[i]);
    j = 1; k = 2;
    while(k < i)
    {
      if((k + 1 < i) && (g[k + 1] > g[k]))
        m = k + 1;
      else
        m = k;
      if(g[m] <= g[j]) break;
      swap(g[j], g[m]);
      j = m; k = j + j;
    }
  }
    //wywolujemy napis
    cout << "Wynik sortowania przez kopcowanie:"<<endl;
        for(i = 1; i <= N; i++)
    //wypisujemy posortowany ciag
        cout << setw(5) << g[i];
        cout << endl << endl;

    //wyswietlamy czas wyliczony przez program
    printf( "Czas: %.4fsek.\n", czas( clock() ) );

    return 0;
}
